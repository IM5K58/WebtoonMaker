import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final String thumb, title, id;
  const DetailScreen({super.key, required this.thumb, required this.title, required this.id});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 2,
        title: Text(title,style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: Colors.green,
        ),),
      ), 
      );
  }
}
