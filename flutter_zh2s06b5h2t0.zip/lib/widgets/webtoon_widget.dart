import 'package:flutter/material.dart';
import 'package:flutter_app/screen/detail_screen.dart';

class WebToon extends StatelessWidget {
  final String thumb, title, id;
  const WebToon({super.key, required this.thumb, required this.title, required this.id});


  @override
  Widget build(BuildContext context) {
    return GestureDetector( //gesture detector를 총해 동작 감지
      onTap:() {Navigator.push(context,MaterialPageRoute(builder: (context)=>
      DetailScreen(title: title, thumb:thumb , id:id ,) //Detail screen 화면으로 이동시킴
      )
      );
      },
      child: Column(
                    children: [
                      Container(
                        clipBehavior: Clip.hardEdge, //컨테이너 안의 이미지들의 외곽 관리
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 12, // 그림자가 어느 범위까지 드리울지 설정
                              offset: Offset(10,10), //그림자 시작 위치 좌표 설정
                              color: Colors.black.withOpacity(0.5), //그림자의 명도 설정


                            )
                          ]
                          
                        ),
                        width:250,
                        child: Image.network(thumb)), //url에서 사진 받아옴
                        SizedBox(
                          height: 10,
                        ),
                      Text(title,style:TextStyle(
                        fontSize: 22,
                      )),
                    ],
                  ),
    ); //필요한 순간 순간마다 업데이트됨
  }
}


