import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_app/services/api_service.dart';
import 'package:flutter_app/models/webtoon_model.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});
  final Future<List<WebtoonModel>> webtoons =ApiService.getTodaysToons(); 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 2,
        title: Text('오늘의 웹툰',style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: Colors.green,
        ),),
      ),
      body: FutureBuilder(
        future: webtoons, //futur builder 가 await를 자동으로 붙여줌
        builder: (context,snapshot){ //snapshot으로 future의 상태를 알 수 있음
          if(snapshot.hasData){
            return ScrollConfiguration(
              behavior: ScrollConfiguration.of(context).copyWith(dragDevices: {
                PointerDeviceKind.mouse,
                },
              ),
              child: Column(
                children:[
                  SizedBox(height: 50,),
                   Expanded(child: makeList(snapshot)), //리스트의 높이 설정
                ]
              )
            );
          }
          else return const Center(
            child:CircularProgressIndicator(), //그 로딩중에 돌아가는 표시 그거 띄워줌
          );
        },
      ),
    );
  }

  ListView makeList(AsyncSnapshot<List<WebtoonModel>> snapshot) {
    return ListView.separated( //좀 더 최적화 된 ListView
            padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
            scrollDirection: Axis.horizontal,
            itemCount: snapshot.data!.length,
            itemBuilder: (context,idx){
                var webtoon = snapshot.data![idx]; //인덱스로 로딩해야하는 아이템에 접근
                return Column(
                  children: [
                    Container(
                      clipBehavior: Clip.hardEdge, //컨테이너 안의 이미지들의 외곽 관리
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 12, // 그림자가 어느 범위까지 드리울지 설정
                            offset: Offset(10,10), //그림자 시작 위치 좌표 설정
                            color: Colors.black.withOpacity(0.5), //그림자의 명도 설정


                          )
                        ]
                        
                      ),
                      width:250,
                      child: Image.network(webtoon.thumb)), //url에서 사진 받아옴
                      SizedBox(
                        height: 10,
                      ),
                    Text(webtoon.title,style:TextStyle(
                      fontSize: 22,
                    )),
                  ],
                ); //필요한 순간 순간마다 업데이트됨
              },
              separatorBuilder: (context,idx)=>SizedBox(  //어떤 간격으로 띄워줄지 결정
                width:20,
              )
            );
  }
}